

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Service
 */
@WebServlet("/Service")
public class Service extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Service() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("name");
		String id=request.getParameter("id");
		String tech=request.getParameter("tech");
		String fee=request.getParameter("fee");
		String university=request.getParameter("university");
		String professor=request.getParameter("professor");
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/amrutha","root","password-1");
			PreparedStatement ps = conn.prepareStatement("insert into service values(?,?,?,?,?,?)");
	        ps.setString(1, name);
	        ps.setString(2, id);
	        ps.setString(3, tech);
	        ps.setString(4, fee);
	        ps.setString(5, university);
	        ps.setString(6, professor);
	        
	        int i = ps.executeUpdate();
	        if(i!=0){
	        	pw.println("Added");
//	        	response.sendRedirect("Admin_Success.html");
	        }else{
	        	pw.println("Not Added");
//	        	response.sendRedirect("Admin_Not_Success.html");
	        }
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
